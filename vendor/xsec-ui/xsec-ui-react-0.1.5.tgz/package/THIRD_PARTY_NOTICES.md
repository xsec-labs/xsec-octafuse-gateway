# Third-party notices

## beUI

Source: https://github.com/starc007/ui-components

Revision: `9f19813a3ea19ce167da9920fba5658b392e4e7f`

Adapted files:

- `components/motion/button/base.tsx`: the React forwardRef/Motion button pattern in `packages/ui-react/src/button.tsx`.
- `lib/ease.ts`: easing and spring parameters in `packages/design-tokens/src/index.ts`.

XSEC adaptations use semantic theme tokens, restrained press animation, explicit loading state, ordinary CSS, and accessible Base UI interaction primitives. The machine-readable source record is `packages/ui-react/upstream.json`.

### Upstream MIT license

MIT License

Copyright (c) 2026 Saurabh Chauhan

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Runtime packages

Package-manager installation retains the licenses shipped by Base UI, Motion, Lucide, React, and React DOM. Exact versions and dependency integrity are recorded in `pnpm-lock.yaml`. The library's own MIT license and the beUI notice accompany both public tarballs.
